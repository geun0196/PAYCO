package PAYCO;

public class Coupon {
	int[] coupon = {10, 15, 20};
	
	public void set10Coupon() {
		System.out.print("10%쿠폰 유저에게 지급완료");
	}
	public void set15Coupon() {
		System.out.print("15%쿠폰 유저에게 지급완료");
	}
	public void set20Coupon() {
		System.out.print("20%쿠폰 유저에게 지급완료");
	}
}
